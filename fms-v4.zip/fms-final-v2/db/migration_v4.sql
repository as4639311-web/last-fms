-- =====================================================================
-- FMS/EMS — ترقية المخطط إلى الإصدار 4 (مرجع/تطبيق يدوي اختياري)
-- ملاحظة: index.php يطبّق كل ما يلي تلقائياً عند أول تشغيل (ensureSchema +
-- runMigrations) بشكل آمن ومتكرر. استخدم هذا الملف فقط إن أردت التطبيق
-- يدوياً من phpMyAdmin. خذ نسخة احتياطية أولاً.
-- رقم الهيكل (Chassis) = العمود الموجود vin — لا عمود مكرر.
-- =====================================================================

CREATE TABLE IF NOT EXISTS schema_migrations (
    version INT PRIMARY KEY,
    applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- المتطلب 1: توسيع بيانات الآليات (نفّذ كل سطر مرة واحدة؛ إن ظهر خطأ
-- "Duplicate column" فالعمود موجود مسبقاً — تجاهله وأكمل)
ALTER TABLE assets ADD COLUMN plate_number VARCHAR(40) NULL AFTER vin;
ALTER TABLE assets ADD COLUMN ownership_type ENUM('OWNED','LEASED','RENTED') NOT NULL DEFAULT 'OWNED';
ALTER TABLE assets ADD COLUMN department VARCHAR(120) NULL;
ALTER TABLE assets ADD COLUMN cost_center VARCHAR(60) NULL;
ALTER TABLE assets ADD COLUMN assigned_driver VARCHAR(190) NULL;
ALTER TABLE assets ADD COLUMN service_interval_days INT NULL;
ALTER TABLE assets ADD COLUMN service_interval_km INT NULL;
ALTER TABLE assets ADD COLUMN last_service_date DATE NULL;
ALTER TABLE assets ADD COLUMN next_service_due_date DATE NULL;
ALTER TABLE assets ADD COLUMN next_service_due_km DECIMAL(12,2) NULL;
ALTER TABLE assets ADD COLUMN notes TEXT NULL;
ALTER TABLE assets ADD COLUMN photo_path VARCHAR(255) NULL;
ALTER TABLE assets ADD INDEX idx_plate (plate_number);
ALTER TABLE assets ADD INDEX idx_next_service (next_service_due_date);

-- المتطلب 2: مواعيد الصيانة
CREATE TABLE IF NOT EXISTS maintenance_appointments (
    id VARCHAR(36) PRIMARY KEY,
    appt_number VARCHAR(40) NOT NULL UNIQUE,
    asset_id VARCHAR(36) NOT NULL,
    requested_by VARCHAR(36) NULL,
    scheduled_at DATETIME NOT NULL,
    scheduled_date DATE NOT NULL,
    preferred_slot ENUM('MORNING','NOON','EVENING') NOT NULL,
    is_exact_time TINYINT(1) NOT NULL DEFAULT 0,
    service_type ENUM('PREVENTIVE','CORRECTIVE','INSPECTION','OTHER') NOT NULL DEFAULT 'PREVENTIVE',
    description TEXT NULL,
    status ENUM('PENDING','CONFIRMED','IN_PROGRESS','COMPLETED','CANCELLED','NO_SHOW') NOT NULL DEFAULT 'PENDING',
    assigned_technician VARCHAR(36) NULL,
    linked_work_order_id VARCHAR(36) NULL,
    workshop_notes TEXT NULL,
    cancel_reason VARCHAR(255) NULL,
    odometer_at_service DECIMAL(12,2) NULL,
    asset_prev_status VARCHAR(30) NULL,
    confirmed_by VARCHAR(36) NULL,
    confirmed_at DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_appt_asset_day (asset_id, scheduled_date, preferred_slot),
    INDEX idx_appt_status_date (status, scheduled_date),
    INDEX idx_appt_tech_day (assigned_technician, scheduled_date),
    INDEX idx_appt_date (scheduled_at),
    FOREIGN KEY (asset_id) REFERENCES assets(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (assigned_technician) REFERENCES users(id),
    FOREIGN KEY (linked_work_order_id) REFERENCES work_orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- «تذكرني» (ضروري لتطبيق الآيفون المثبَّت الذي يفقد كوكي الجلسة عند إغلاقه)
CREATE TABLE IF NOT EXISTS auth_tokens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    selector CHAR(24) NOT NULL UNIQUE,
    validator_hash CHAR(64) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    user_agent VARCHAR(190) NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tok_user (user_id),
    INDEX idx_tok_exp (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO schema_migrations (version) VALUES (4);
